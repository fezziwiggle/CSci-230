//Maezy Haldeman: maezy.haldeman@und.edu
//CSCI 230: HW 5

#ifndef HW5C
#define HW5C

void SEARCH(struct _data *BlackBox, char *name, int size);

#endif
