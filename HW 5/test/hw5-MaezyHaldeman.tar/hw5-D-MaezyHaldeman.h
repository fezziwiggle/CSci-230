//Maezy Haldeman: maezy.haldeman@und.edu
//CSCI 230: HW 5

#ifndef HW5D
#define HW5D


void FREE(struct _data *BlackBox, int size);

#endif
