//Maezy Haldeman: maezy.haldeman@und.edu
//CSCI 230: HW 5

#ifndef HW5B
#define HW5B

struct _data *LOAD(FILE *stream, int size);

#endif
