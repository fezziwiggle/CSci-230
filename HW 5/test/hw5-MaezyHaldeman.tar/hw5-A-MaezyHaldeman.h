//Maezy Haldeman: maezy.haldeman@und.edu
//CSCI 230: HW 5

#ifndef HW5A
#define HW5A



//function to open a file(stream) and return an integer indicating the num of lines

struct _data {
	char *name;
	long number;
};

int SCAN(FILE *(*stream));

#endif
