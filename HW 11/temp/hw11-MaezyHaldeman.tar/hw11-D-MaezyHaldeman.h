//Maezy Haldeman: maezy.haldeman@und.edu
//CSCI 230: HW 11

#ifndef HW11D
#define HW11D


void FREE(struct _data *BlackBox, int size);

#endif
