//Maezy Haldeman: maezy.haldeman@und.edu
//CSCI 230: HW 11

#ifndef HW11A
#define HW11A



//function to open a file(stream) and return an integer indicating the num of lines

/*struct _data {
	char *name;
	long number;
};*/

int SCAN(FILE *(*stream));

#endif
