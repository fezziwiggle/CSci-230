//Maezy Haldeman: maezy.haldeman@und.edu
//CSCI 230: HW 11

#ifndef HW11C
#define HW11C

void SEARCH(struct _data *BlackBox, char *name, int size);

#endif
