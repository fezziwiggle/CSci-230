//Maezy Haldeman: maezy.haldeman@und.edu
//CSCI 230: HW 11

#ifndef HW11B
#define HW11B

struct _data *LOAD(FILE *stream, int size);

#endif
