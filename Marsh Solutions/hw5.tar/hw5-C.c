#include "./hw5-C.h"

/*****************************************************/
/* Search for name.                                  */
/*****************************************************/
void SEARCH(struct _data *BlackBox, char *name, int size) {
int i;
int found = 0;
   printf("*******************************************\n");
   for (i = 0; i < size; i++) {
       if (!strcmp(name, BlackBox[i].name)) {
          printf("The name was found at the %d entry.\n", i);
          found = 1;
          break;
       }
   } 
   if (found == 0) {
      printf("The name was NOT found.\n");
   }
   printf("*******************************************\n");
}

