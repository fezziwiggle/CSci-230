#include <stdio.h>
#include <stdlib.h>

#ifndef _structure_
#define _structure_
struct _data {					// Define the structure (nothing is global here).
   char *name;
   long number;
}; 
#endif

void FREE(struct _data *, int);
