#include "./hw5-A.h"

/*****************************************************/
/* See how big the file is.                          */
/*****************************************************/
int SCAN(FILE *(*stream)) {			// We want to pass stream by reference (a pointer to a pointer).
int size = 0;
size_t chrCount;
char *text;
   // Open the file and make sure it was opened.
   if ((*stream = fopen("./hw4.data", "r")) == NULL) {
      printf("ERROR - Could not open hw4.data file.\n");
      exit(0);
   }
   // Use getline to read in a full line of data/text.
   while (1) {
      text = NULL;
      chrCount = 0;
      getline(&text, &chrCount, *stream);	// getline expects 3 pointer arguments.
      free(text);
      if (feof(*stream)) break;
      size++;
   }
   return size;
}

