#include "./hw5-A.h"
#include "./hw5-B.h"
#include "./hw5-C.h"
#include "./hw5-D.h"

/*****************************************************/
/* Main                                              */
/*****************************************************/
int main(int argv, char **argc) {
int size;
FILE *stream;
struct _data *BlackBox;
    if (argv == 1) {
       printf("*******************************************\n");
       printf("* You must include a name to search for.  *\n");
       printf("*******************************************\n");
    }
    if (argv == 2) {
       size = SCAN(&stream);
       BlackBox = LOAD(stream, size);
       SEARCH(BlackBox, argc[1], size);
   }
}

