#include "./hw5-B.h"

/*****************************************************/
/* Load the file.                                    */
/*****************************************************/
struct _data *LOAD(FILE *stream, int size) {	// Here we can just pass stream by value (we're not changing it).
int i;
size_t chrCount;
char *text, *phone, *name;
struct _data *BlackBox;
   // Allocate memory for array of struct.
   if ((BlackBox = (struct _data*)calloc(size, sizeof(struct _data))) == NULL) {
      printf("ERROR - Could not allocate memory.\n");
      exit(0);
   }
   // Rewind the file.
   rewind(stream);
   // Use getline to read in ALL of the data/text.
   for (i = 0; i < size; i++) {
      text = NULL;
      chrCount = 0;
      getline(&text, &chrCount, stream);
      name  = strtok(text, " ");		// strtok extracts all characters to " ".
      phone = strtok(NULL, "\n");		// strtok extracts all characters to "\n".
      // Allocate memory for name part of struct.
      if ((BlackBox[i].name = (char*)calloc(strlen(name)+1, sizeof(char))) == NULL) {
         printf("ERROR - Could not allocate memory.\n");
         exit(0);
      }
      strcpy(BlackBox[i].name, name);		// copy name into struct.
      BlackBox[i].number = atol(phone);		// we want number as an long integer.
      free(text);
   }
   fclose(stream);
   return BlackBox;				// Return pointer to dynamic array.
}

